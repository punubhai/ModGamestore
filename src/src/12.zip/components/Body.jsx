import React, { useState, useEffect } from "react";
import "./body.css";

// Popup component
const Popup = ({ game, onClose }) => {
  const handleDownload = () => {
    alert(`Downloading ${game.title}...`);
  };

  return (
    <div className="popup-overlay">
      <div className="popup-content">
        <h2>{game.title}</h2>
        <img src={game.image} alt={game.title} className="popup-image" />
        <p>Genre: {game.genre}</p>
        <p>Description: {game.description || 'No description available'}</p>
        <button onClick={onClose} className="popup-close-button">Close</button>
        <button onClick={handleDownload} className="popup-download-button">Download</button>
      </div>
    </div>
  );
};

const Body = ({ searchTerm = '', sortOrder = 'asc', selectedGenre = '' }) => {
  const [filteredGames, setFilteredGames] = useState([]);
  const [selectedGame, setSelectedGame] = useState(null);

  const games = [
    { id: 1, title: "Skyrim Special Edition", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/489830/header.jpg?t=1547595804", genre: "RPG", description: "An enhanced version of Skyrim with better graphics and more features." },
    { id: 2, title: "Skyrim", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/489830/header.jpg?t=1547595804", genre: "RPG", description: "The original Skyrim game, a beloved RPG with a vast open world." },
    { id: 3, title: "Fallout 4", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/377160/header.jpg?t=1547595653", genre: "RPG", description: "A post-apocalyptic RPG with a rich story and open-world exploration." },
    { id: 4, title: "Fallout New Vegas", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/388900/header.jpg?t=1547595704", genre: "RPG", description: "A Fallout game set in a post-apocalyptic Las Vegas with multiple endings." },
    { id: 5, title: "Cyberpunk 2077", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg?t=1587535025", genre: "RPG", description: "An open-world RPG set in a dystopian future with rich storytelling." },
    { id: 6, title: "Stardew Valley", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg?t=1547595724", genre: "Simulation", description: "A farming simulation game with a charming aesthetic." },
    { id: 7, title: "Oblivion", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/22380/header.jpg?t=1547595521", genre: "RPG", description: "The fourth installment in The Elder Scrolls series with a rich world." },
    { id: 8, title: "Baldur's Gate 3", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/108600/header.jpg?t=1547595684", genre: "RPG", description: "A modern take on the classic RPG with deep character development." },
    { id: 9, title: "Fallout 3", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/377160/header.jpg?t=1547595653", genre: "RPG", description: "An open-world RPG set in a post-apocalyptic Washington D.C." },
    { id: 10, title: "The Witcher 3", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/292030/header.jpg?t=1547595590", genre: "RPG", description: "An award-winning RPG with an immersive story and open-world exploration." },
    { id: 11, title: "Mount & Blade II: Bannerlord", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/268500/header.jpg?t=1547595531", genre: "Strategy", description: "A medieval strategy game with a focus on realistic combat." },
    { id: 12, title: "Monster Hunter: World", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/391550/header.jpg?t=1547595706", genre: "Action RPG", description: "An action RPG focused on hunting large monsters in a vibrant world." },
    { id: 13, title: "Blade & Sorcery", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/865990/header.jpg?t=1579620877", genre: "Action", description: "A VR game focusing on melee combat and magic." },
    { id: 14, title: "Dragon Age: Origins", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/367500/header.jpg?t=1547595698", genre: "RPG", description: "A fantasy RPG with rich storytelling and character development." },
    { id: 15, title: "Morrowind", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/22380/header.jpg?t=1547595521", genre: "RPG", description: "An open-world RPG with a rich lore and vast exploration." },
    { id: 16, title: "Modding Tools", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/893040/header.jpg?t=1586893059", genre: "Tools", description: "Tools for modding various games." },
    { id: 17, title: "Starfield", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/1675200/header.jpg?t=1654408394", genre: "RPG", description: "A space RPG from the creators of Skyrim and Fallout." },
    { id: 18, title: "Elden Ring", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/1245620/header.jpg?t=1623122977", genre: "Action RPG", description: "An open-world action RPG with a focus on exploration and lore." }
  ];

  useEffect(() => {
    const lowercasedSearchTerm = searchTerm.toLowerCase();
    const filtered = games.filter(game => 
      game.title.toLowerCase().includes(lowercasedSearchTerm) &&
      (selectedGenre ? game.genre === selectedGenre : true)
    );

    const sortedFilteredGames = filtered.sort((a, b) => 
      sortOrder === "asc" ? a.title.localeCompare(b.title) : b.title.localeCompare(a.title)
    );

    setFilteredGames(sortedFilteredGames);
  }, [searchTerm, sortOrder, selectedGenre]);

  const handleGameClick = (game) => {
    setSelectedGame(game);
  };

  const handleClosePopup = () => {
    setSelectedGame(null);
  };

  return (
    <div className="App">
      <header className="App-header">
        <div className="game-container">
          {filteredGames.map((game) => (
            <div key={game.id} className="game-card" onClick={() => handleGameClick(game)}>
              <img src={game.image} alt={game.title} />
              <div className="game-info">
                <h3>{game.title}</h3>
                <p>Genre: {game.genre}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="content-container">
          <h1>WELCOME TO GAMEFORGE</h1>
          <p>
            We host mods for android games from uploaders serving our members with available downloads to date. If you can mod it, we'll host it.
          </p>
          <button className="browse-button">BROWSE ALL FILES</button>
        </div>
        <div className="upload-box">
          <h2>Upload Games</h2>
          <button className="upload-button">Upload</button>
        </div>
        {selectedGame && (
          <Popup game={selectedGame} onClose={handleClosePopup} />
        )}
      </header>
    </div>
  );
};

export default Body;
