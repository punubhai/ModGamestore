import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import './Header.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { useAuth } from '../AuthContext';
import logoImage from './image/download (1).png';

const games = [
  { id: 1, title: "Cyberpunk 2077", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg?t=1587535025" },
  { id: 2, title: "Stardew Valley", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg?t=1547595724" },
  { id: 3, title: "Oblivion", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/22380/header.jpg?t=1547595521" },
  { id: 4, title: "Baldur's Gate 3", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/108600/header.jpg?t=1547595684" },
  { id: 5, title: "Fallout 3", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/377160/header.jpg?t=1547595653" },
  { id: 6, title: "The Witcher 3", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/292030/header.jpg?t=1547595590" },
  { id: 7, title: "Mount & Blade II: Bannerlord", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/268500/header.jpg?t=1547595531" },
  { id: 8, title: "Monster Hunter: World", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/391550/header.jpg?t=1547595706" },
  { id: 9, title: "Dragon Age: Origins", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/367500/header.jpg?t=1547595698" },
  { id: 10, title: "Morrowind", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/22380/header.jpg?t=1547595521" },
  { id: 11, title: "Starfield", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/1675200/header.jpg?t=1654408394" },
  { id: 12, title: "Elden Ring", image: "https://cdn.cloudflare.steamstatic.com/steam/apps/1245620/header.jpg?t=1623122977" },
];

const Header = ({ onSearch, sortOrder, onGenreFilter }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isGamesDropdownOpen, setGamesDropdownOpen] = useState(false);
  const [isModsDropdownOpen, setModsDropdownOpen] = useState(false);
  const [isLoginDropdownOpen, setLoginDropdownOpen] = useState(false);
  const [isRegisterDropdownOpen, setRegisterDropdownOpen] = useState(false);
  const [filteredGames, setFilteredGames] = useState([]);

  const { isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();

  const handleSearch = (event) => {
    event.preventDefault();
    onSearch(searchTerm, sortOrder);
    setFilteredGames([]);
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleSearch(event);
    }
  };

  const handleGenreSelect = (genre) => {
    onGenreFilter(genre);
    setGamesDropdownOpen(false);
    if (genre === 'All') {
      onGenreFilter('');
    }
  };

  const handleSearchChange = (event) => {
    const value = event.target.value;
    setSearchTerm(value);

    if (value) {
      const filtered = games.filter(game =>
        game.title.toLowerCase().includes(value.toLowerCase())
      );
      setFilteredGames(filtered);
    } else {
      setFilteredGames([]);
    }
  };

  const handleSuggestionClick = (game) => {
    setSearchTerm(game.title);
    onSearch(game.title, sortOrder);
    setFilteredGames([]);
  };

  const handleClearSearch = () => {
    setSearchTerm('');
    setFilteredGames([]);
  };

  const handleSignInClick = () => {
    navigate('/login');
  };

  const handleRegisterClick = () => {
    navigate('/register'); // Navigate to the Register page
  };

  const handleUploadClick = () => {
    navigate('/upload-games');
  };

  return (
    <header className="header">
      <div className="header__logo">
        <Link to="/">
          <img src={logoImage} alt="GameForge Logo" />
          <span className="header__logo-text">GAMEFORGE</span>
        </Link>
      </div>
      <nav className="header__nav">
        <ul className="header__nav-list">
          <li
            className="header__nav-item"
            onMouseEnter={() => setGamesDropdownOpen(true)}
            onMouseLeave={() => setGamesDropdownOpen(false)}
          >
            <button className="header__nav-button">
              Games
              <i className="fas fa-chevron-down"></i>
            </button>
            {isGamesDropdownOpen && (
              <div className="header__dropdown">
                <a href="#" onClick={() => handleGenreSelect('All')}>All</a>
                <a href="#" onClick={() => handleGenreSelect('Action')}>Action</a>
                <a href="#" onClick={() => handleGenreSelect('Adventure')}>Adventure</a>
                <a href="#" onClick={() => handleGenreSelect('RPG')}>RPG</a>
                <a href="#" onClick={() => handleGenreSelect('Strategy')}>Strategy</a>
              </div>
            )}
          </li>
          <li
            className="header__nav-item"
            onMouseEnter={() => setModsDropdownOpen(true)}
            onMouseLeave={() => setModsDropdownOpen(false)}
          >
            <button className="header__nav-button">
              Mods
              <i className="fas fa-chevron-down"></i>
            </button>
            {isModsDropdownOpen && (
              <div className="header__dropdown">
                <a href="#">Popular</a>
                <a href="#">New Releases</a>
                <a href="#">Top Rated</a>
              </div>
            )}
          </li>
          {isAuthenticated ? (
            <>
              <li className="header__nav-item" onClick={handleUploadClick}>
                <button className="header__nav-button">
                  Upload Games
                </button>
              </li>
              <li className="header__nav-item">
                <button className="header__nav-button" onClick={logout}>
                  <i className="fas fa-user-circle"></i> Logout
                </button>
              </li>
            </>
          ) : (
            <>
              <li
                className="header__nav-item"
                onMouseEnter={() => setLoginDropdownOpen(true)}
                onMouseLeave={() => setLoginDropdownOpen(false)}
              >
                <button className="header__nav-button">
                  Login
                  <i className="fas fa-chevron-down"></i>
                </button>
                {isLoginDropdownOpen && (
                  <div className="header__dropdown">
                    <a href="#" onClick={handleSignInClick}>Sign In</a>
                    <a href="#">Forgot Password</a>
                  </div>
                )}
              </li>
              <li
                className="header__nav-item"
                onMouseEnter={() => setRegisterDropdownOpen(true)}
                onMouseLeave={() => setRegisterDropdownOpen(false)}
              >
                <button className="header__nav-button">
                  Register
                  <i className="fas fa-chevron-down"></i>
                </button>
                {isRegisterDropdownOpen && (
                  <div className="header__dropdown">
                    <a href="#" onClick={handleRegisterClick}>Create Account</a> {/* Link to registration */}
                    <a href="#">Join Us</a>
                  </div>
                )}
              </li>
            </>
          )}
        </ul>
      </nav>
      <div className="header__search">
        <input
          type="text"
          placeholder="Search games..."
          value={searchTerm}
          onChange={handleSearchChange}
          onKeyPress={handleKeyPress}
        />
        {searchTerm && (
          <button className="header__clear-btn" onClick={handleClearSearch}>
            &times;
          </button>
        )}
        {filteredGames.length > 0 && (
          <div className="header__suggestions">
            {filteredGames.map(game => (
              <div
                key={game.id}
                className="header__suggestion-item"
                onClick={() => handleSuggestionClick(game)}
              >
                <img src={game.image} alt={game.title} className="suggestion-image" />
                <span>{game.title}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
